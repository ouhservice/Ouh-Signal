const cfg = OUH_CONFIG;
const loginPanel = document.getElementById('loginPanel');
const ordersPanel = document.getElementById('ordersPanel');
const loginMsg = document.getElementById('loginMsg');
const ordersMsg = document.getElementById('ordersMsg');
const list = document.getElementById('ordersList');
let client = null;
function ready(){return window.supabase && cfg.supabaseUrl && cfg.supabaseAnonKey && !cfg.supabaseUrl.includes('YOUR-PROJECT') && !cfg.supabaseAnonKey.includes('YOUR_SUPABASE');}
if (ready()) { client = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey); client.auth.getSession().then(({data})=>{if(data.session) showOrders();}); }
else loginMsg.textContent = 'Supabase belum dikonfigurasi. Isi supabaseUrl dan supabaseAnonKey di config.js setelah mengikuti SETUP-SUPABASE.md.';
function showOrders(){loginPanel.classList.add('hidden');ordersPanel.classList.remove('hidden');loadOrders();}
document.getElementById('loginBtn').addEventListener('click', async()=>{
 if(!client){loginMsg.textContent='Konfigurasi Supabase belum lengkap.';return;}
 loginMsg.textContent='Memeriksa login…';
 const {error}=await client.auth.signInWithPassword({email:document.getElementById('email').value.trim(),password:document.getElementById('password').value});
 if(error){loginMsg.textContent='Login gagal: '+error.message;return;} loginMsg.textContent='';showOrders();
});
document.getElementById('refreshBtn').addEventListener('click',loadOrders);
document.getElementById('logoutBtn').addEventListener('click',async()=>{await client.auth.signOut();ordersPanel.classList.add('hidden');loginPanel.classList.remove('hidden');list.replaceChildren();});
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function signedUrl(path){const {data,error}=await client.storage.from(cfg.storageBucket).createSignedUrl(path,300);if(error)throw error;return data.signedUrl;}
async function loadOrders(){if(!client)return;ordersMsg.textContent='Memuat order…';list.replaceChildren();
 const {data,error}=await client.from('orders').select('*').order('created_at',{ascending:false}).limit(100);
 if(error){ordersMsg.textContent='Gagal memuat order: '+error.message;return;}
 ordersMsg.textContent=`Menampilkan ${data.length} order terbaru (maksimal 100).`;
 if(!data.length){list.innerHTML='<div class="admin-card">Belum ada order masuk.</div>';return;}
 for(const o of data){
  const card=document.createElement('article');card.className='order-item';
  card.innerHTML=`<h2>Order ${esc(o.id)}</h2><p><b>Dibuat:</b> ${esc(new Date(o.created_at).toLocaleString('id-ID'))}</p><p><b>Nama:</b> ${esc(o.customer_name)} &nbsp; <b>WhatsApp:</b> ${esc(o.customer_phone)}</p><p><b>Perangkat:</b> ${esc(o.device)} &nbsp; <b>IMEI:</b> ${esc(o.imei1)}</p><p><b>Paket:</b> ${esc(o.plan_name)} &nbsp; <b>Harga:</b> ${esc(new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(o.price||0))}</p><p><b>Kendala:</b> ${esc(o.issue||'-')}</p><label>Status: <select class="statusSelect"><option ${o.status==='Baru'?'selected':''}>Baru</option><option ${o.status==='Diproses'?'selected':''}>Diproses</option><option ${o.status==='Selesai'?'selected':''}>Selesai</option><option ${o.status==='Ditolak'?'selected':''}>Ditolak</option></select></label> <button class="saveStatus">SIMPAN STATUS</button><div class="photos"><div><h3>Identitas IMEI</h3><p class="imeiPhoto muted">Membuka foto…</p></div><div><h3>Bukti Pembayaran</h3><p class="paymentPhoto muted">Membuka foto…</p></div></div>`;
  card.querySelector('.saveStatus').addEventListener('click',async()=>{const status=card.querySelector('.statusSelect').value;const {error}=await client.from('orders').update({status}).eq('id',o.id);ordersMsg.textContent=error?'Gagal menyimpan status: '+error.message:'Status order '+o.id+' diperbarui.';});
  list.appendChild(card);
  try{const [a,b]=await Promise.all([signedUrl(o.imei_photo_path),signedUrl(o.payment_photo_path)]);card.querySelector('.imeiPhoto').outerHTML=`<a href="${a}" target="_blank" rel="noopener"><img src="${a}" alt="Identitas IMEI"></a>`;card.querySelector('.paymentPhoto').outerHTML=`<a href="${b}" target="_blank" rel="noopener"><img src="${b}" alt="Bukti pembayaran"></a>`;}catch(err){card.querySelector('.imeiPhoto').textContent='Foto tidak dapat dibuka: '+err.message;card.querySelector('.paymentPhoto').textContent='Foto tidak dapat dibuka: '+err.message;}
 }
}
