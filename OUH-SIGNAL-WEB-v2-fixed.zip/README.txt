OUH SIGNAL — Website

Website statis untuk layanan order OUH SIGNAL (Android & iOS).

File utama:
- index.html: halaman konsumen
- script.js: pilihan paket, upload foto ke Supabase, dan pembukaan WhatsApp
- config.js: nomor WA, harga/paket, serta konfigurasi Supabase
- admin.html + admin.js: dashboard admin untuk melihat order/foto dan memperbarui status
- SETUP-SUPABASE.md: panduan setup cloud gratis
- style.css dan assets/: tampilan dan gambar

PENTING: Upload foto online belum aktif sampai project Supabase dibuat, bucket privat dan tabel dikonfigurasi, serta URL/anon key diisi pada config.js. Ikuti SETUP-SUPABASE.md.
Jangan pernah menaruh Supabase service_role key di file frontend.

Foto disimpan dalam bucket privat. Pelanggan tidak bisa membaca daftar order atau melihat foto pelanggan lain; admin harus login untuk membuka dashboard.
WhatsApp menerima ringkasan order, sedangkan foto dilihat melalui dashboard admin (tidak otomatis dilampirkan ke chat WhatsApp).
