const cfg = OUH_CONFIG;
const rupiah = n => new Intl.NumberFormat("id-ID", {style:"currency", currency:"IDR", maximumFractionDigits:0}).format(n);
const plansEl = document.getElementById("plans");
const selectedEl = document.getElementById("selectedPlan");
let selectedPlan = null;

cfg.plans.forEach(p => {
  const el = document.createElement("article");
  el.className = "plan";
  el.innerHTML = `<span class="tag">${p.type}</span><h3>${p.duration}</h3><div class="type">PROCESS MODE // ${p.type}</div><div class="price">${rupiah(p.price)}</div><div class="eta">ESTIMASI ${p.eta}</div><p>${p.note}</p><button type="button">PILIH PAKET</button>`;
  el.addEventListener("click", () => selectPlan(p, el));
  plansEl.appendChild(el);
});
function selectPlan(p, el){
  selectedPlan = p;
  document.querySelectorAll(".plan").forEach(x=>x.classList.remove("selected"));
  el.classList.add("selected");
  selectedEl.textContent = `PAKET DIPILIH: ${p.duration} • ${p.type} • ${rupiah(p.price)} • ETA ${p.eta}`;
  document.getElementById("order").scrollIntoView({behavior:"smooth", block:"start"});
}
const waUrl = "https://wa.me/" + cfg.whatsapp;
["navWa","paymentWa","aboutWa"].forEach(id => { const a = document.getElementById(id); if (a) { a.href = waUrl; a.target = "_blank"; a.rel = "noopener"; }});
document.getElementById("year").textContent = new Date().getFullYear();

function supabaseReady(){
  return window.supabase && cfg.supabaseUrl && cfg.supabaseAnonKey &&
    !cfg.supabaseUrl.includes("YOUR-PROJECT") && !cfg.supabaseAnonKey.includes("YOUR_SUPABASE");
}
document.getElementById("orderForm").addEventListener("submit", async e => {
  e.preventDefault();
  const msgEl = document.getElementById("formMsg");
  if (!selectedPlan) { alert("Silakan pilih paket terlebih dahulu."); document.getElementById("paket").scrollIntoView({behavior:"smooth"}); return; }
  if (!supabaseReady()) {
    msgEl.textContent = "Penyimpanan online belum diaktifkan. Admin perlu mengisi URL dan anon key Supabase di config.js terlebih dahulu.";
    msgEl.scrollIntoView({behavior:"smooth", block:"center"}); return;
  }
  const form = e.target;
  const fd = new FormData(form);
  const imeiFile = fd.get("imeiProof"), paymentFile = fd.get("paymentProof");
  const allowed = f => f && f.type.startsWith("image/") && f.size <= 8 * 1024 * 1024;
  if (!allowed(imeiFile) || !allowed(paymentFile)) { msgEl.textContent = "Pastikan kedua file adalah gambar dan masing-masing maksimal 8 MB."; return; }
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true; msgEl.textContent = "Mengunggah foto dan menyimpan order… jangan tutup halaman.";
  try {
    const client = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey);
    const orderId = crypto.randomUUID();
    const safeName = name => name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-100);
    const imeiPath = `${orderId}/imei-${Date.now()}-${safeName(imeiFile.name)}`;
    const paymentPath = `${orderId}/payment-${Date.now()}-${safeName(paymentFile.name)}`;
    const uploadOne = async (path, file) => {
      const {error} = await client.storage.from(cfg.storageBucket).upload(path, file, {upsert:false, contentType:file.type});
      if (error) throw error;
    };
    await uploadOne(imeiPath, imeiFile);
    await uploadOne(paymentPath, paymentFile);
    const order = {
      id: orderId,
      customer_name: String(fd.get("customerName") || "").trim(),
      customer_phone: String(fd.get("customerPhone") || "").trim(),
      device: String(fd.get("device") || "").trim(),
      imei1: String(fd.get("imei1") || "").trim(),
      issue: String(fd.get("issue") || "").trim(),
      plan_name: `${selectedPlan.duration} ${selectedPlan.type}`,
      price: selectedPlan.price,
      eta: selectedPlan.eta,
      imei_photo_path: imeiPath,
      payment_photo_path: paymentPath,
      status: "Baru"
    };
    const {error: dbError} = await client.from("orders").insert(order);
    if (dbError) throw dbError;
    const text = ["🔐 *OUH SIGNAL — ORDER BARU*", "", `🆔 Order ID: ${orderId}`, `👤 Nama: ${order.customer_name}`, `📱 No. WA: ${order.customer_phone}`, `📲 Device: ${order.device}`, `🔢 IMEI 1: ${order.imei1}`, `🧾 Paket: ${order.plan_name}`, `💰 Harga: ${rupiah(order.price)}`, `⏱️ Estimasi: ${order.eta}`, `📝 Kendala: ${order.issue || "-"}`, "", "✅ Foto IMEI dan bukti pembayaran sudah tersimpan online.", "🔎 Admin dapat melihat foto melalui dashboard admin.", "— Sent from OUH SIGNAL Web"].join("\n");
    msgEl.textContent = "Order tersimpan dan foto berhasil diunggah. WhatsApp akan dibuka untuk mengirim detail order.";
    window.open(waUrl + "?text=" + encodeURIComponent(text), "_blank", "noopener");
    form.reset(); selectedPlan = null; selectedEl.textContent = "Belum memilih paket";
    document.querySelectorAll(".plan").forEach(x=>x.classList.remove("selected"));
  } catch (err) {
    console.error(err);
    msgEl.textContent = "Order belum berhasil disimpan. Periksa koneksi dan konfigurasi Supabase. Detail: " + (err.message || "kesalahan tidak diketahui");
  } finally { button.disabled = false; }
});
