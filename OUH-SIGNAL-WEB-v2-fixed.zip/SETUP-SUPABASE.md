# Panduan mengaktifkan upload foto & dashboard admin OUH SIGNAL

Project ini memakai Supabase Free untuk database, login admin, dan penyimpanan foto privat. Website belum bisa mengunggah foto sebelum langkah konfigurasi berikut dilakukan. Tidak ada akun/kunci Supabase yang bisa dibuat otomatis dari ZIP ini.

## 1. Buat project Supabase
1. Buka https://supabase.com/ lalu daftar/login dan buat project baru.
2. Simpan password database di tempat aman.
3. Dari dashboard project, buka **Project Settings → API** (atau **Connect**) dan salin **Project URL** serta **anon/public key**.
4. Buka `config.js`. Ganti `https://YOUR-PROJECT.supabase.co` dengan Project URL dan `YOUR_SUPABASE_ANON_KEY` dengan anon/public key.
5. Jangan pernah memasukkan `service_role` key ke `config.js` atau file frontend.

## 2. Buat bucket foto privat
1. Buka **Storage → New bucket**.
2. Nama bucket harus persis `order-photos`.
3. Pastikan bucket **Private** (jangan aktifkan Public bucket).
4. Jika tersedia pengaturan batas file, set maksimal 8 MB dan izinkan hanya image/jpeg, image/png, image/webp, image/gif.

## 3. Buat tabel dan aturan akses
Buka **SQL Editor → New query**, tempel dan jalankan SQL berikut:

```sql
create table if not exists public.orders (
  id uuid primary key,
  created_at timestamptz not null default now(),
  customer_name text not null,
  customer_phone text not null,
  device text not null,
  imei1 text not null,
  issue text,
  plan_name text not null,
  price integer not null,
  eta text not null,
  imei_photo_path text not null,
  payment_photo_path text not null,
  status text not null default 'Baru' check (status in ('Baru','Diproses','Selesai','Ditolak'))
);

alter table public.orders enable row level security;
revoke all on public.orders from anon, authenticated;
grant insert on public.orders to anon, authenticated;
grant select, update on public.orders to authenticated;

drop policy if exists "Public can submit order" on public.orders;
create policy "Public can submit order" on public.orders
for insert to anon, authenticated with check (
  status = 'Baru'
  and price > 0
  and char_length(customer_name) between 1 and 120
  and char_length(customer_phone) between 5 and 30
  and char_length(imei1) between 8 and 20
  and imei_photo_path like id::text || '/%'
  and payment_photo_path like id::text || '/%'
);

drop policy if exists "Admins can view orders" on public.orders;
create policy "Admins can view orders" on public.orders
for select to authenticated using (auth.uid() is not null);

drop policy if exists "Admins can update order status" on public.orders;
create policy "Admins can update order status" on public.orders
for update to authenticated using (auth.uid() is not null)
with check (auth.uid() is not null);

-- Pelanggan boleh mengunggah foto ke folder bernama UUID order.
-- Mereka tidak mendapat izin membaca foto atau daftar file.
drop policy if exists "Customers can upload order photos" on storage.objects;
create policy "Customers can upload order photos" on storage.objects
for insert to anon, authenticated with check (
  bucket_id = 'order-photos'
  and (storage.foldername(name))[1] ~ '^[0-9a-fA-F-]{36}$'
);

drop policy if exists "Admins can read order photos" on storage.objects;
create policy "Admins can read order photos" on storage.objects
for select to authenticated using (bucket_id = 'order-photos' and auth.uid() is not null);
```

**Catatan keamanan:** aturan di atas memberi pengunjung publik kemampuan mengirim order dan mengunggah foto, tetapi hanya pengguna yang login yang dapat membaca order/foto. Supabase anon key memang digunakan di frontend; keamanan berasal dari RLS dan Storage policies. Untuk website publik yang ramai, tambahkan CAPTCHA/rate limiting dan validasi backend agar mengurangi spam dan pemalsuan data.

## 4. Buat akun admin
1. Di **Authentication → Sign In / Providers** (atau pengaturan Authentication), nonaktifkan public sign-ups / pendaftaran pengguna baru jika opsi tersebut tersedia. Jangan membiarkan pelanggan membuat akun admin sendiri.
2. Di Supabase buka **Authentication → Users → Add user**.
3. Buat email dan password khusus admin. Jangan bagikan password ini ke pelanggan.
4. Buka halaman `admin.html` di domain website, lalu login dengan akun tersebut.
5. Admin dapat melihat foto melalui URL bertanda tangan yang berlaku 5 menit, dan memperbarui status order.

## 5. Upload dan tes website
1. Upload semua isi folder ZIP ke hosting yang mendukung file HTML/CSS/JS statis (misalnya GitHub Pages, Netlify, atau hosting web biasa). Pastikan `index.html`, `admin.html`, `admin.js`, `config.js`, `script.js`, `style.css`, dan folder `assets` berada pada satu folder publik.
2. Buka halaman website memakai HTTPS.
3. Buat satu order percobaan dengan foto uji, cek apakah detail order masuk ke WhatsApp, lalu buka `admin.html` dan pastikan order/foto muncul.
4. Jangan memakai foto identitas atau bukti pembayaran asli untuk tes pertama.

## Penting
- Order yang dibuat sebelum fitur ini aktif tidak otomatis memiliki foto di cloud. Foto order lama harus diminta ulang atau dikirim manual oleh pelanggan.
- WhatsApp tetap dibuka untuk mengirim ringkasan order; file foto tidak otomatis dilampirkan di chat. Foto tersimpan di bucket privat dan admin melihatnya melalui dashboard.
- `admin.html` bukan tautan rahasia. Proteksi datanya berasal dari login Supabase dan kebijakan RLS.
